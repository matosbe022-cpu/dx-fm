param(
  [Parameter(Mandatory=$true)][string]$DirectoryApi,
  [Parameter(Mandatory=$true)][string]$ServerName,
  [Parameter(Mandatory=$true)][string]$ServerUrl,
  [Parameter(Mandatory=$true)][string]$AdminToken,
  [string]$City = '',
  [string]$Country = 'Brasil',
  [string]$Description = '',
  [ValidateSet('public','private')][string]$Visibility = 'public'
)

$body = @{
  name = $ServerName
  url = $ServerUrl
  city = $City
  country = $Country
  description = $Description
  visibility = $Visibility
} | ConvertTo-Json

Invoke-RestMethod -Method Post -Uri "$($DirectoryApi.TrimEnd('/'))/servers" `
  -Headers @{ Authorization = "Bearer $AdminToken" } `
  -ContentType 'application/json' -Body $body
