const express = require('express');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const app = express();
app.disable('x-powered-by');
app.use(express.json({ limit: '16kb', strict: true }));
const PORT = Number(process.env.PORT || 8787);
const TOKEN = process.env.DIRECTORY_ADMIN_TOKEN || '';
const DB = process.env.DIRECTORY_DB || path.join(__dirname, 'servers.json');

function read() {
  try {
    const rows = JSON.parse(fs.readFileSync(DB, 'utf8'));
    return Array.isArray(rows) ? rows : [];
  } catch (error) {
    if (error.code !== 'ENOENT') console.error('Could not read directory database:', error.message);
    return [];
  }
}
function write(rows) {
  const temp = `${DB}.${process.pid}.tmp`;
  fs.mkdirSync(path.dirname(DB), { recursive: true });
  fs.writeFileSync(temp, JSON.stringify(rows, null, 2), { mode: 0o600 });
  fs.renameSync(temp, DB);
}
function auth(req, res, next) {
  const supplied = (req.get('authorization') || '').replace(/^Bearer\s+/i, '');
  if (!TOKEN || supplied.length !== TOKEN.length || !crypto.timingSafeEqual(Buffer.from(supplied), Buffer.from(TOKEN))) {
    return res.status(401).json({ error: 'unauthorized' });
  }
  next();
}
function clean(value, max) { return String(value || '').trim().slice(0, max); }
function validUrl(raw) {
  try {
    const u = new URL(raw);
    return ['http:', 'https:'].includes(u.protocol) && !!u.hostname && !u.username && !u.password;
  } catch { return false; }
}
function publicView(x) {
  return { id: x.id, name: x.name, url: x.url, country: x.country, city: x.city, description: x.description, updatedAt: x.updatedAt };
}

app.get('/health', (_req, res) => res.json({ ok: true, service: 'FM-DX Directory' }));
app.get('/api/servers', (_req, res) => {
  res.set('Cache-Control', 'public, max-age=30');
  res.json(read().filter(x => x.visibility === 'public').map(publicView));
});
app.get('/api/servers/:id', (req, res) => {
  const item = read().find(x => x.id === req.params.id && x.visibility === 'public');
  if (!item) return res.status(404).json({ error: 'not_found' });
  res.json(publicView(item));
});
app.post('/api/servers', auth, (req, res) => {
  const body = req.body || {};
  const name = clean(body.name, 80);
  const url = clean(body.url, 300);
  const visibility = body.visibility || 'public';
  if (!name || !validUrl(url) || !['public', 'private'].includes(visibility)) {
    return res.status(400).json({ error: 'invalid_server_data', message: 'Informe nome, URL http(s) válida e visibilidade public/private.' });
  }
  const generated = name.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
  const id = clean(body.id || generated, 64);
  if (!/^[a-zA-Z0-9_-]+$/.test(id)) return res.status(400).json({ error: 'invalid_id' });
  const rows = read();
  const entry = {
    id, name, url,
    country: clean(body.country, 60),
    city: clean(body.city, 60),
    description: clean(body.description, 240),
    visibility,
    updatedAt: new Date().toISOString()
  };
  const index = rows.findIndex(x => x.id === id);
  if (index >= 0) rows[index] = entry; else rows.push(entry);
  write(rows);
  res.status(index >= 0 ? 200 : 201).json({ ok: true, id, visibility });
});
app.delete('/api/servers/:id', auth, (req, res) => {
  const rows = read();
  const next = rows.filter(x => x.id !== req.params.id);
  write(next);
  res.json({ ok: true, removed: rows.length - next.length });
});

if (!TOKEN) console.warn('WARNING: DIRECTORY_ADMIN_TOKEN is not set; registration and deletion will be unavailable.');
app.listen(PORT, '0.0.0.0', () => console.log(`FM-DX Directory listening on ${PORT}`));
