package br.com.fmdx.android

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.View
import android.view.ViewGroup
import android.webkit.*
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private val defaultDirectory = "https://SEU-DIRETORIO.example/api"
    private val prefs by lazy { getSharedPreferences("fmdx", MODE_PRIVATE) }
    private lateinit var root: LinearLayout
    private lateinit var status: TextView
    private var web: WebView? = null
    private var publicRows = JSONArray()
    private var nativeReceiverServer: NativeReceiverServer? = null
    private val bg = Color.rgb(8, 21, 34)
    private val panel = Color.rgb(19, 43, 64)
    private val cyan = Color.rgb(53, 182, 232)
    private val white = Color.WHITE
    private val muted = Color.rgb(158, 184, 204)

    private val directoryApi: String
        get() = prefs.getString("directory_api", defaultDirectory) ?: defaultDirectory

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
    }

    private fun releaseWebView() {
        web?.let { current ->
            current.stopLoading()
            current.loadUrl("about:blank")
            current.clearHistory()
            (current.parent as? ViewGroup)?.removeView(current)
            current.removeAllViews()
            current.destroy()
        }
        web = null
    }

    private fun base(title: String): LinearLayout {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 20, 20, 16)
            setBackgroundColor(bg)
        }
        root.addView(TextView(this).apply {
            text = title; textSize = 25f; setTextColor(white); typeface = Typeface.DEFAULT_BOLD
        })
        status = TextView(this).apply {
            text = "FM-DX • Rádio definida por software"; textSize = 13f
            setTextColor(muted); setPadding(0, 5, 0, 16)
        }
        root.addView(status)
        return root
    }

    private fun scroll(content: LinearLayout) {
        val scroller = ScrollView(this).apply { isFillViewport = true; addView(content) }
        setContentView(scroller)
    }

    private fun button(label: String, action: () -> Unit): Button = Button(this).apply {
        text = label; isAllCaps = false; textSize = 14f; setTextColor(white)
        backgroundTintList = android.content.res.ColorStateList.valueOf(panel)
        setOnClickListener { action() }
    }

    private fun field(hint: String, value: String = ""): EditText = EditText(this).apply {
        this.hint = hint; setText(value); setHintTextColor(muted); setTextColor(white)
        inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_URI
        textSize = 15f; setSingleLine(true); setPadding(14, 8, 14, 8)
        backgroundTintList = android.content.res.ColorStateList.valueOf(cyan)
    }

    private fun label(text: String): TextView = TextView(this).apply {
        this.text = text; setTextColor(cyan); textSize = 15f; typeface = Typeface.DEFAULT_BOLD
        setPadding(0, 16, 0, 7)
    }

    private fun showHome() {
        releaseWebView()
        val content = base("FM-DX Android")
        content.addView(TextView(this).apply {
            text = "Sua rede de receptores FM-DX"; setTextColor(white); textSize = 17f
        })
        content.addView(TextView(this).apply {
            text = "Conecte-se a servidores públicos ou adicione um endereço privado compartilhado pelo proprietário."
            setTextColor(muted); textSize = 13f; setPadding(0, 5, 0, 14)
        })
        val address = field("Endereço do servidor (https://...)")
        content.addView(address, matchWrap())
        content.addView(button("CONECTAR") {
            normalize(address.text.toString())?.let { openServer(it) } ?: toast("Digite um endereço http:// ou https:// válido")
        }, matchWrap())
        content.addView(button("SALVAR ENDEREÇO / CONVITE") {
            normalize(address.text.toString())?.let { saveServer(it); toast("Servidor salvo nos seus favoritos") }
                ?: toast("Informe um endereço válido")
        }, matchWrap())
        content.addView(button("PROCURAR SERVIDORES PÚBLICOS") { loadDirectory() }, matchWrap())
        content.addView(button("MEUS SERVIDORES E CONVITES") { showSaved() }, matchWrap())
        content.addView(button("CONFIGURAÇÕES DO DIRETÓRIO") { showSettings() }, matchWrap())
        content.addView(button("📻 RECEPTOR NATIVO / SERVIDOR") { showNativeReceiver() }, matchWrap())
        content.addView(label("COMO FUNCIONA"))
        content.addView(TextView(this).apply {
            text = "O servidor FM-DX e o receptor compatível continuam funcionando no computador do proprietário. Este aplicativo conecta os ouvintes ao servidor pela internet ou rede local."
            setTextColor(muted); textSize = 13f
        })
        scroll(content)
    }

    private fun loadDirectory() {
        if (directoryApi.contains("SEU-DIRETORIO")) { toast("Configure o endereço do diretório primeiro"); showSettings(); return }
        showDirectoryLoading()
        thread {
            try {
                val endpoint = directoryApi.trimEnd('/') + "/servers"
                val conn = (URL(endpoint).openConnection() as HttpURLConnection).apply {
                    requestMethod = "GET"; connectTimeout = 10000; readTimeout = 10000
                }
                val code = conn.responseCode
                val body = (if (code in 200..299) conn.inputStream else conn.errorStream)
                    ?.bufferedReader()?.use { it.readText() } ?: "[]"
                conn.disconnect()
                if (code !in 200..299) throw Exception("Diretório respondeu HTTP $code")
                publicRows = JSONArray(body)
                runOnUiThread { showDirectoryResults("") }
            } catch (e: Exception) {
                runOnUiThread { status.text = "Falha ao consultar o diretório"; toast(e.message ?: "Erro de conexão") }
            }
        }
    }

    private fun showDirectoryLoading() {
        val content = base("Servidores públicos")
        content.addView(TextView(this).apply { text = "Consultando diretório..."; setTextColor(muted) })
        content.addView(button("VOLTAR") { showHome() }, matchWrap())
        scroll(content)
    }

    private fun showDirectoryResults(filter: String) {
        val content = base("Servidores públicos")
        content.addView(button("← INÍCIO") { showHome() }, matchWrap())
        val search = field("Pesquisar por nome, cidade ou país", filter)
        content.addView(search, matchWrap())
        val results = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(results)
        fun render(term: String) {
            results.removeAllViews()
            var count = 0
            for (i in 0 until publicRows.length()) {
                val item = publicRows.optJSONObject(i) ?: continue
                val name = item.optString("name", "Servidor FM-DX")
                val city = item.optString("city")
                val country = item.optString("country")
                val description = item.optString("description")
                val searchable = "$name $city $country $description".lowercase()
                if (term.isNotBlank() && !searchable.contains(term.lowercase())) continue
                count++
                val url = item.optString("url")
                val details = listOf(city, country).filter { it.isNotBlank() }.joinToString(" • ")
                results.addView(label(name))
                if (details.isNotBlank()) results.addView(TextView(this).apply { text = details; setTextColor(muted); textSize = 12f })
                if (description.isNotBlank()) results.addView(TextView(this).apply { text = description; setTextColor(muted); textSize = 12f })
                results.addView(button("CONECTAR") { normalize(url)?.let { openServer(it) } ?: toast("Endereço inválido") }, matchWrap())
                results.addView(button("SALVAR NOS FAVORITOS") { normalize(url)?.let { saveServer(it); toast("Servidor salvo") } }, matchWrap())
            }
            if (count == 0) results.addView(TextView(this).apply {
                text = if (publicRows.length() == 0) "Nenhum servidor público cadastrado." else "Nenhum servidor corresponde à pesquisa."
                setTextColor(muted); setPadding(0, 18, 0, 18)
            })
            status.text = "$count servidor(es) encontrado(s)"
        }
        search.addTextChangedListener(SimpleWatcher { render(it) })
        render(filter)
        content.addView(button("ATUALIZAR LISTA") { loadDirectory() }, matchWrap())
        scroll(content)
    }

    private fun showSaved() {
        val content = base("Meus servidores")
        content.addView(button("← INÍCIO") { showHome() }, matchWrap())
        val arr = JSONArray(prefs.getString("servers", "[]"))
        if (arr.length() == 0) content.addView(TextView(this).apply {
            text = "Nenhum endereço salvo. Você pode adicionar servidores privados na tela inicial."
            setTextColor(muted); setPadding(0, 18, 0, 18)
        })
        for (i in 0 until arr.length()) {
            val address = arr.optString(i)
            content.addView(label(address))
            content.addView(button("CONECTAR") { openServer(address) }, matchWrap())
            content.addView(button("REMOVER DOS FAVORITOS") { removeServer(address); showSaved() }, matchWrap())
        }
        scroll(content)
    }

    private fun showNativeReceiver() {
        releaseWebView()
        val content = base("Receptor nativo / servidor")
        content.addView(TextView(this).apply {
            text = "Use o receptor FM nativo do aparelho como fonte do servidor local. Quando o aparelho expuser RADIO_TUNER, outros dispositivos na mesma rede Wi-Fi poderão abrir o endereço do servidor e ouvir o áudio em tempo real."
            setTextColor(white); textSize = 14f; setPadding(0, 0, 0, 12)
        })
        content.addView(label("STATUS DO RECEPTOR"))
        val statusView = TextView(this).apply { textSize = 14f; setTextColor(muted); setPadding(0, 4, 0, 12) }
        content.addView(statusView)

        fun refresh() {
            val s = nativeReceiverServer?.status()
            statusView.text = if (s == null || !s.running) {
                "Servidor parado\nO aplicativo vai testar se este aparelho expõe RADIO_TUNER."
            } else {
                "SERVIDOR ATIVO\nPorta: ${s.port}\n${s.message}"
            }
        }

        content.addView(button("INICIAR SERVIDOR DO RECEPTOR") {
            if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                requestPermissions(arrayOf(android.Manifest.permission.RECORD_AUDIO), 1001)
                toast("Autorize o microfone/captura de áudio e toque novamente.")
                return@button
            }
            if (nativeReceiverServer == null) nativeReceiverServer = NativeReceiverServer()
            val result = nativeReceiverServer!!.start()
            if (result.running) toast("Servidor iniciado na porta ${result.port}") else toast(result.message)
            refresh()
        }, matchWrap())
        content.addView(button("PARAR SERVIDOR") {
            nativeReceiverServer?.stop(); refresh()
        }, matchWrap())
        content.addView(button("COPIAR ENDEREÇO DO SERVIDOR") {
            val s = nativeReceiverServer?.status()
            if (s != null && s.running) {
                val host = getLocalIpAddress()
                val address = "http://$host:${s.port}/"
                val cm = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
                cm.setPrimaryClip(android.content.ClipData.newPlainText("Servidor FM-DX", address))
                toast(address)
            } else toast("Inicie o servidor primeiro")
        }, matchWrap())
        content.addView(label("TV DIGITAL NATIVA"))
        content.addView(TextView(this).apply {
            text = "A TV digital não possui uma API universal de captura no Android. Nesta versão deixamos a camada preparada, mas ela só poderá ser ativada por uma integração específica do fabricante/hardware do aparelho."
            setTextColor(muted); textSize = 13f
        })
        content.addView(label("IMPORTANTE"))
        content.addView(TextView(this).apply {
            text = "Não é garantido que todo celular permita que um aplicativo comum acesse o sintonizador FM. O Android restringe APIs internas/não-SDK; por isso o app testa a capacidade real e informa o resultado, sem simular um receptor que não existe."
            setTextColor(muted); textSize = 13f; setPadding(0, 0, 0, 12)
        })
        content.addView(button("← VOLTAR") { showHome() }, matchWrap())
        refresh()
        scroll(content)
    }

    private fun getLocalIpAddress(): String {
        return try {
            java.net.NetworkInterface.getNetworkInterfaces().toList()
                .flatMap { it.inetAddresses.toList() }
                .firstOrNull { !it.isLoopbackAddress && it is java.net.Inet4Address }
                ?.hostAddress ?: "127.0.0.1"
        } catch (_: Exception) { "127.0.0.1" }
    }

    private fun showSettings() {
        val content = base("Configurações")
        content.addView(button("← INÍCIO") { showHome() }, matchWrap())
        content.addView(label("ENDEREÇO DO DIRETÓRIO PÚBLICO"))
        val api = field("https://seu-dominio.com/api", directoryApi)
        content.addView(api, matchWrap())
        content.addView(button("SALVAR CONFIGURAÇÃO") {
            val value = api.text.toString().trim().trimEnd('/')
            val valid = normalize(value)
            if (valid == null || !valid.startsWith("https://")) toast("Informe uma URL HTTPS válida para o diretório público")
            else { prefs.edit().putString("directory_api", valid).apply(); toast("Endereço do diretório salvo"); showHome() }
        }, matchWrap())
        content.addView(TextView(this).apply {
            text = "O diretório público precisa estar publicado em um servidor HTTPS. Servidores privados podem ser adicionados diretamente pelo endereço ou convite, sem aparecer na lista pública."
            setTextColor(muted); textSize = 13f; setPadding(0, 16, 0, 0)
        })
        scroll(content)
    }

    private fun saveServer(address: String) {
        val old = JSONArray(prefs.getString("servers", "[]")); val next = JSONArray()
        for (i in 0 until old.length()) if (old.optString(i) != address) next.put(old.optString(i))
        next.put(address); prefs.edit().putString("servers", next.toString()).apply()
    }

    private fun removeServer(address: String) {
        val old = JSONArray(prefs.getString("servers", "[]")); val next = JSONArray()
        for (i in 0 until old.length()) if (old.optString(i) != address) next.put(old.optString(i))
        prefs.edit().putString("servers", next.toString()).apply()
    }

    private fun openServer(address: String) {
        releaseWebView()
        val view = WebView(this); web = view
        view.settings.javaScriptEnabled = true
        view.settings.domStorageEnabled = true
        view.settings.mediaPlaybackRequiresUserGesture = false
        view.settings.allowFileAccess = false
        view.settings.allowContentAccess = false
        view.settings.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
        view.settings.safeBrowsingEnabled = true
        view.webChromeClient = WebChromeClient()
        view.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(v: WebView?, request: WebResourceRequest?): Boolean {
                val target = request?.url ?: return true
                return target.scheme != "https" && target.scheme != "http"
            }
            override fun onPageFinished(v: WebView?, url: String?) { status.text = "Servidor: ${url ?: address}" }
            override fun onReceivedError(v: WebView?, request: WebResourceRequest?, error: WebResourceError?) {
                if (request?.isForMainFrame == true) toast("Não foi possível carregar o servidor. Verifique o endereço e a conexão.")
            }
        }
        val shell = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg) }
        shell.addView(button("← VOLTAR À LISTA") { view.stopLoading(); showHome() }, matchWrap())
        shell.addView(view, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(shell)
        view.loadUrl(address)
    }

    private fun normalize(raw: String): String? {
        val value = raw.trim().trimEnd('/')
        if (!value.startsWith("https://") && !value.startsWith("http://")) return null
        return try {
            val u = URL(value)
            if (u.host.isBlank() || u.userInfo != null) null else value
        } catch (_: Exception) { null }
    }

    private fun matchWrap() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = 7 }
    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    @Deprecated("Deprecated in Android API; retained for compatibility with the Activity base class")
    override fun onBackPressed() {
        val current = web
        if (current != null) {
            if (current.canGoBack()) current.goBack() else showHome()
        } else {
            super.onBackPressed()
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 1001) {
            if (grantResults.isNotEmpty() && grantResults[0] == android.content.pm.PackageManager.PERMISSION_GRANTED) {
                toast("Permissão concedida. Abra Receptor nativo / servidor novamente para iniciar.")
            } else {
                toast("Sem permissão de áudio, o receptor não pode ser testado.")
            }
        }
    }

    override fun onDestroy() {
        nativeReceiverServer?.stop()
        nativeReceiverServer = null
        releaseWebView()
        super.onDestroy()
    }

    private class SimpleWatcher(val changed: (String) -> Unit) : android.text.TextWatcher {
        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
        override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { changed(s?.toString() ?: "") }
        override fun afterTextChanged(s: android.text.Editable?) {}
    }
}
