# FM-DX Android 0.3.0

## Novidades
- Adicionada tela nativa para cadastrar o próprio servidor FM-DX no diretório.
- O cadastro permite nome, URL HTTPS, cidade, país, descrição e visibilidade pública/privada.
- O token administrativo é armazenado nas preferências privadas do aplicativo e enviado somente no cabeçalho Authorization.
- O cadastro é feito em segundo plano para não bloquear a interface.
- O endpoint `/health` do diretório informa versão e horário da verificação.
- Versão Android atualizada para 0.3.0 (versionCode 3).

## Limitações conhecidas
- Esta versão ainda é código-fonte; não foi compilada em APK neste ambiente porque Android SDK/Gradle não estão instalados.
- Não há verificação automática de disponibilidade dos servidores listados.
- A reprodução em segundo plano ainda depende de implementação e teste de um serviço Android próprio; não é anunciada como suportada nesta versão.
- O diretório é um catálogo, não retransmite áudio.
- O token administrativo deve ser usado somente com diretório HTTPS confiável.
